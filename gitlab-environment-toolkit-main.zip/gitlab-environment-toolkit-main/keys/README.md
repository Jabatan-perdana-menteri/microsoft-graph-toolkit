This folder can be used to store any keys or secrets required for use with Terraform and / or Ansible.
