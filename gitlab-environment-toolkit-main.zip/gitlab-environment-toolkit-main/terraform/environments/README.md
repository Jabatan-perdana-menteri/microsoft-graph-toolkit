Folder for storing Terraform config for environments.
