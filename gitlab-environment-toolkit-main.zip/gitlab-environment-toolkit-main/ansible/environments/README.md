Folder for storing all Inventory config and custom files for your environments.

Refer to the [docs for further guidance](../../docs/environment_configure.md#2-setup-the-environments-inventory-and-config).
