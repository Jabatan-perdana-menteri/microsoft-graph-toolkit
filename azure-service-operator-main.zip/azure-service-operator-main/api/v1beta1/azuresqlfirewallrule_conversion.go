// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

package v1beta1

func (*AzureSqlFirewallRule) Hub() {}
