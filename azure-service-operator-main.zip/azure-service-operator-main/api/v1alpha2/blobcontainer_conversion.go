// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

package v1alpha2

func (*BlobContainer) Hub() {}
