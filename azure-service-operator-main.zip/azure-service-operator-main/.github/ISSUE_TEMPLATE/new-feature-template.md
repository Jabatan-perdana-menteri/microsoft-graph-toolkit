---
name: New feature template
about: Request a new feature
title: 'Feature: <Briefly describe the feature>'
labels: new-feature
assignees: ''

---

<Describe the feature request>

