---
name: Improvement template
about: Request an improvement to an existing feature or behavior
labels: task
assignees: ''

---

**Describe the current behavior**
A description of how things are today.

**Describe the improvement**
How should things be changed or improved?

**Additional context**
Add any other context about the suggested improvement.
