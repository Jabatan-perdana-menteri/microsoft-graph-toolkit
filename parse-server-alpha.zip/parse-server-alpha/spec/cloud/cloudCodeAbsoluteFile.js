Parse.Cloud.define('cloudCodeInFile', () => {
  return 'It is possible to define cloud code in a file.';
});
