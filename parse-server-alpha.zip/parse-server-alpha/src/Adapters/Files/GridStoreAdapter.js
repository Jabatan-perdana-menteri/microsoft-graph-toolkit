// Note: GridStore was replaced by GridFSBucketAdapter by default in 2018 by @flovilmart
throw new Error(
  'GridStoreAdapter: GridStore is no longer supported by parse server and mongodb, use GridFSBucketAdapter instead.'
);
