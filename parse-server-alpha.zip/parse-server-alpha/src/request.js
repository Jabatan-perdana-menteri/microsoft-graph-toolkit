module.exports = require('./cloud-code/httpRequest');
