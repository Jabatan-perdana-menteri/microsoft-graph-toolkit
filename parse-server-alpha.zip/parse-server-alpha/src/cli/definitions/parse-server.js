const ParseServerDefinitions = require('../../Options/Definitions').ParseServerOptions;
export default ParseServerDefinitions;
