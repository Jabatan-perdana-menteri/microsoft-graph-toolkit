const LiveQueryServerOptions = require('../../Options/Definitions').LiveQueryServerOptions;
export default LiveQueryServerOptions;
