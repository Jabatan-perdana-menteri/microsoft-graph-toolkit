/** @flow */
export default (errorMessage: string): any => {
  throw errorMessage;
};
